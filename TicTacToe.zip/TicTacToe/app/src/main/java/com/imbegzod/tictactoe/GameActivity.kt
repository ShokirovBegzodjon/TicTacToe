package com.imbegzod.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import com.imbegzod.tictactoe.databinding.ActivityGameBinding

private lateinit var binding: ActivityGameBinding
private var tag = -1
private var isgaming = true
private var person = 1
private var winX = 0
private var winO = 0

private var list:MutableList<Int> = arrayListOf()
private var winList = arrayOf(
    arrayOf(0,1,2),
    arrayOf(3,4,5),
    arrayOf(6,7,8),

    arrayOf(0,3,6),
    arrayOf(1,4,7),
    arrayOf(2,5,8),

    arrayOf(0,4,8),
    arrayOf(2,4,6),

)
class GameActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tag = intent.getIntExtra("tag", -1)
        when (tag) {
            0 -> {
                binding.person2Name.text = "Person2"
                binding.person1Name.text = "Person1"
                binding.person2Icon.setImageResource(R.drawable.baseline_person_24)
            }

            1 -> {
                binding.person2Name.text = "Al"
                binding.person1Name.text = "Person"
                binding.person2Icon.setImageResource(R.drawable.robot_solid)
            }

            2 -> {
                binding.person2Name.text = "Online"
                binding.person1Name.text = "Person"
                binding.person2Icon.setImageResource(R.drawable.globe_solid)
            }
        }
        resetGame()
        binding.restart.setOnClickListener { restartGame() }
        binding.reset.setOnClickListener { resetGame() }
        binding.exit.setOnClickListener { finish() }
    }

    private fun resetGame() {
        person = if (tag == 1) {
            1
        } else {
            (0..1).random()
        }
        alpha(person)
        list.clear()
        for (i in 0..8) {
            list.add(-1)
        }
        isgaming = true
        for (i in 0 until binding.gridlayout.childCount)
            (binding.gridlayout.getChildAt(i) as ImageView).setImageResource(0)
        binding.finish.visibility = View.INVISIBLE
    }

    private fun restartGame() {
        winO = 0
        winX = 0
        binding.person2Win.text = "Wins: 0"
        binding.person1Win.text = "Wins: 0"
        resetGame()
    }

    fun onClickImage(view: View) {
        val imageView = view as ImageView
        val clickTag = imageView.tag.toString().toInt()
        if (isgaming && list[clickTag] == -1 && (tag == 0 || (tag == 1 && person == 1))) {
            if (person == 1) {
                imageView.setImageResource(R.drawable.black_x)
                list[clickTag] = 1
                person = 0
            } else {
                imageView.setImageResource(R.drawable.black_0)
                list[clickTag] = 0
                person = 1
            }
           winGame()
        }
    }

    private fun winGame(){
        for (lists in winList) {
            if (list[lists[0]] == list[lists[1]] &&
                list[lists[1]] == list[lists[2]] &&
                list[lists[0]] != -1
            ) {
                if (list[lists[0]] == 1) {
                    finishGame(1, lists)
                } else
                    finishGame(0, lists)
            }
        }
        if (isgaming) {
            var thereA1 = false
            for (i in 0 until list.size) {
                if (list[i] == -1)
                    thereA1 = true
            }
            if (!thereA1)
                finishGame(2, arrayOf(0, 0))
        }
        alpha(person)
        alClick()
    }

    private fun alClick() {
        if (person == 0 && tag == 1 && isgaming) {
            while (true) {
                val i = (0..8).random()
                if (list[i] == -1) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        list[i] = 0
                        person = 1
                        (binding.gridlayout.getChildAt(i) as ImageView).setImageResource(R.drawable.black_0)
                        winGame()
                    }, 1000)
                    break
                }
            }
        }
    }


    private fun finishGame(tag: Int,list:Array<Int>){
        binding.finish.visibility = View.VISIBLE
        when(tag){
            0->{
                ++winO
                binding.person2Win.text = "Wins: $winO"
                binding.win.text = "${binding.person2Name.text.toString().toUpperCase()} WINNER"
                binding.winicon.setImageResource(R.drawable.win)

                for (i in 0 until binding.gridlayout.childCount) {
                    val imageView = binding.gridlayout.getChildAt(i) as ImageView
                    val index = (imageView).tag.toString().toInt()
                    for (element in list)
                        if (element == index) {
                            imageView.setImageResource(R.drawable.green_0)
                        }
                }
            }
            1->{
                ++winX
                binding.person1Win.text = "Wins: $winX"
                binding.win.text = "${binding.person1Name.text.toString().toUpperCase()} WINNER"
                binding.winicon.setImageResource(R.drawable.win)

                for (i in 0 until binding.gridlayout.childCount) {
                    val imageView = binding.gridlayout.getChildAt(i) as ImageView
                    val index = (imageView).tag.toString().toInt()
                    for (element in list)
                        if (element == index) {
                            imageView.setImageResource(R.drawable.green_x)
                        }
                }
            }
            2->{
                binding.win.text = "GAME DRAW"
                binding.winicon.setImageResource(R.drawable.draw)
            }
        }
        isgaming = false

    }

    private fun alpha(person: Int){
        if (person == 1){
            binding.person1.alpha = 1f
            binding.person2.alpha = 0.5f
        }else{
            binding.person1.alpha = 0.5f
            binding.person2.alpha = 1f
        }
    }
}