package com.imbegzod.tictactoe

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import com.imbegzod.tictactoe.databinding.ActivityMainBinding

private lateinit var binding:ActivityMainBinding
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        oneShow()
        binding.personvsperson.setOnClickListener { intentTag(0) }
        binding.personvsrobot.setOnClickListener { intentTag(1) }
        binding.personvsonline.setOnClickListener { intentTag(2) }

    }
    fun oneShow(){
        binding.oneShow.visibility = View.VISIBLE
        Handler(Looper.getMainLooper()).postDelayed({
                     binding.oneShow.visibility = View.INVISIBLE
        },1500)
    }
    fun intentTag(tag: Int){
        startActivity(
            Intent(this,GameActivity::class.java).apply {
                putExtra("tag",tag)
            }
        )
    }
}